package itj.seosong.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import itj.seosong.Entities.User;


public interface UserRepository extends JpaRepository<User, Long> {
}