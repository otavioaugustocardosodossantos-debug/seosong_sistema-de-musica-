package itj.seosong.Controller;

import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import itj.seosong.Entities.Playlist;
import itj.seosong.Entities.Song;
import itj.seosong.Services.LlmService;

@CrossOrigin
@RestController
@RequestMapping("/llm")
public class LlmController {

    private final LlmService service;

    public LlmController(LlmService service) {
        this.service = service;
    }

    // 1. Recomendação de músicas/artistas
    @PostMapping("/users/{userId}/recommendations")
    public ResponseEntity<Map<String, String>> recommend(@PathVariable Long userId) {
        String texto = service.recommendForUser(userId);
        return ResponseEntity.ok(Map.of("recommendations", texto));
    }

    // 2. Descrição automática de playlist
    @PostMapping("/playlists/{playlistId}/description")
    public ResponseEntity<Playlist> generateDescription(@PathVariable Long playlistId) {
        Playlist playlist = service.generatePlaylistDescription(playlistId);
        return ResponseEntity.ok(playlist);
    }

    // 3. Playlist a partir de um humor/vibe
    // corpo esperado: { "userId": 1, "vibe": "estudar à noite", "name": "opcional" }
    @PostMapping("/vibe-playlist")
    public ResponseEntity<Playlist> vibePlaylist(@RequestBody Map<String, Object> body) {
        Long userId = Long.valueOf(body.get("userId").toString());
        String vibe = (String) body.get("vibe");
        String nome = (String) body.get("name");
        Playlist playlist = service.generateVibePlaylist(userId, vibe, nome);
        return ResponseEntity.status(201).body(playlist);
    }

    // 4. Resumo do perfil musical do usuário
    @PostMapping("/users/{userId}/profile-summary")
    public ResponseEntity<Map<String, String>> profileSummary(@PathVariable Long userId) {
        String texto = service.summarizeUserProfile(userId);
        return ResponseEntity.ok(Map.of("summary", texto));
    }

    // 5. Detectar gênero de uma música
    @PostMapping("/musics/{songId}/detect-genre")
    public ResponseEntity<Song> detectGenre(@PathVariable Long songId) {
        Song song = service.detectGenre(songId);
        return ResponseEntity.ok(song);
    }
}