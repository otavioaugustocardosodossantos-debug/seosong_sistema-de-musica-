package itj.seosong.Services;

import itj.seosong.Entities.Playlist;
import itj.seosong.Entities.Song;
import itj.seosong.Repositories.PlaylistRepository;
import itj.seosong.Repositories.SongRepository;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PlaylistService {

    private final PlaylistRepository playlistRepository;
    private final SongRepository songRepository;

    public PlaylistService(PlaylistRepository playlistRepository, SongRepository songRepository) {
        this.playlistRepository = playlistRepository;
        this.songRepository = songRepository;
    }

    public List<Playlist> findAll() {
        return playlistRepository.findAll();
    }

    public Playlist findById(Long id) {
        return playlistRepository.findById(id).orElseThrow(() -> new RuntimeException("Playlist não encontrada"));
    }

    public Playlist save(Playlist playlist) {
        return playlistRepository.save(playlist);
    }

    public void deleteById(Long id) {
        playlistRepository.deleteById(id);
    }

    public Optional<Playlist> update(Long id, Playlist data) {
        return playlistRepository.findById(id).map(existing -> {
            existing.setName(data.getName());
            existing.setPhoto(data.getPhoto());
            existing.setUser(data.getUser());
            return playlistRepository.save(existing);
        });
    }

    public Optional<Playlist> addSong(Long playlistId, Long songId) {
        Optional<Playlist> playlistOpt = playlistRepository.findById(playlistId);
        Optional<Song> songOpt = songRepository.findById(songId);

        if (playlistOpt.isEmpty() || songOpt.isEmpty()) {
            return Optional.empty();
        }

        Playlist playlist = playlistOpt.get();
        Song song = songOpt.get();

        boolean jaTem = playlist.getSongs().stream()
                .anyMatch(s -> s.getId().equals(song.getId()));

        if (!jaTem) {
            playlist.getSongs().add(song);
            playlistRepository.save(playlist);
        }

        return Optional.of(playlist);
    }

    public Optional<Playlist> removeSong(Long playlistId, Long songId) {
        return playlistRepository.findById(playlistId).map(playlist -> {
            playlist.getSongs().removeIf(s -> s.getId().equals(songId));
            return playlistRepository.save(playlist);
        });
    }
}