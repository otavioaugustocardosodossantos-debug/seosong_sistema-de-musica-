package itj.seosong.Services;

import itj.seosong.Entities.Song;
import itj.seosong.Repositories.SongRepository;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MusicService {

    private final SongRepository musicRepository;

    public MusicService(SongRepository musicRepository) {
        this.musicRepository = musicRepository;
    }

    public List<Song> findAll() {
        return musicRepository.findAll();
    }

    public Song findById(Long id) {
        return musicRepository.findById(id).orElseThrow(() -> new RuntimeException("Música não encontrada"));
    }

    public Song save(Song music) {
        return musicRepository.save(music);
    }

    public void deleteById(Long id) {
        musicRepository.deleteById(id);
    }

    public Optional<Song> update(Long id, Song data) {
        return musicRepository.findById(id).map(existing -> {
            existing.setName(data.getName());
            existing.setAlbum(data.getAlbum());
            existing.setYear(data.getYear());
            existing.setDuration(data.getDuration());
            existing.setGenre(data.getGenre());
            existing.setPhoto(data.getPhoto());
            existing.setArtist(data.getArtist());
            return musicRepository.save(existing);
        });
    }
}