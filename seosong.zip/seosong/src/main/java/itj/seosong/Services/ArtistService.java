package itj.seosong.Services;

import itj.seosong.Entities.Artist;
import itj.seosong.Repositories.ArtistRepository;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ArtistService {

    private final ArtistRepository artistRepository;

    public ArtistService(ArtistRepository artistRepository) {
        this.artistRepository = artistRepository;
    }

    public List<Artist> findAll() {
        return artistRepository.findAll();
    }

    public Artist findById(Long id) {
        return artistRepository.findById(id).orElseThrow(() -> new RuntimeException("Artista não encontrado"));
    }

    public Artist save(Artist artist) {
        return artistRepository.save(artist);
    }

    public void deleteById(Long id) {
        artistRepository.deleteById(id);
    }

    public Optional<Artist> update(Long id, Artist data) {
        return artistRepository.findById(id).map(existing -> {
            existing.setName(data.getName());
            existing.setFormationDate(data.getFormationDate());
            existing.setDescription(data.getDescription());
            existing.setPhoto(data.getPhoto());
            return artistRepository.save(existing);
        });
    }
}