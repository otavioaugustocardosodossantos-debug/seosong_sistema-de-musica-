package itj.seosong.Services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import itj.seosong.Entities.Playlist;
import itj.seosong.Entities.Song;
import itj.seosong.Entities.User;
import itj.seosong.Repositories.PlaylistRepository;
import itj.seosong.Repositories.SongRepository;
import itj.seosong.Repositories.UserRepository;

@Service
public class LlmService {

    private final RestTemplate restTemplate;
    private final UserRepository userRepository;
    private final PlaylistRepository playlistRepository;
    private final SongRepository songRepository;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Value("${llm.api.url}")
    private String apiUrl;

    @Value("${llm.api.key}")
    private String apiKey;

    @Value("${llm.api.model}")
    private String model;

    public LlmService(RestTemplate restTemplate, UserRepository userRepository,
                       PlaylistRepository playlistRepository, SongRepository songRepository) {
        this.restTemplate = restTemplate;
        this.userRepository = userRepository;
        this.playlistRepository = playlistRepository;
        this.songRepository = songRepository;
    }

    // ===== 1. Recomendação de músicas/artistas com base no gosto do usuário =====

    public String recommendForUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));

        String favoritos = user.getFavoriteSongs().stream()
                .map(this::describe)
                .collect(Collectors.joining(", "));

        String daPlaylist = user.getPlaylists().stream()
                .flatMap(p -> p.getSongs().stream())
                .map(this::describe)
                .distinct()
                .collect(Collectors.joining(", "));

        String gosto = (favoritos + ", " + daPlaylist).replaceAll("^, |, $", "");

        if (gosto.isBlank()) {
            return "Esse usuário ainda não tem favoritos nem playlists com músicas — adicione algumas primeiro para receber recomendações.";
        }

        String prompt = "Com base nestas músicas de um usuário: " + gosto +
                ". Sugira 5 artistas ou músicas parecidas que ele provavelmente vai gostar. " +
                "Responda em português, em uma lista simples e curta, sem introdução.";

        return askLlm(prompt);
    }

    // ===== 2. Geração automática de descrição de playlist =====

    public Playlist generatePlaylistDescription(Long playlistId) {
        Playlist playlist = playlistRepository.findById(playlistId)
                .orElseThrow(() -> new RuntimeException("Playlist não encontrada"));

        if (playlist.getSongs().isEmpty()) {
            playlist.setDescription("Essa playlist ainda não tem músicas.");
            return playlistRepository.save(playlist);
        }

        playlist.setDescription(buildDescription(playlist.getName(), playlist.getSongs()));
        return playlistRepository.save(playlist);
    }

    // ===== 3. Gerar playlist a partir de um humor/vibe =====

    public Playlist generateVibePlaylist(Long userId, String vibe, String nomeDesejado) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));

        List<Song> catalogo = songRepository.findAll();

        if (catalogo.isEmpty()) {
            throw new RuntimeException("Não há músicas cadastradas no catálogo ainda.");
        }

        String listaCatalogo = catalogo.stream()
                .map(s -> s.getId() + " - " + describe(s))
                .collect(Collectors.joining(" | "));

        String prompt = "Catálogo de músicas disponíveis (formato id - nome (artista)): " + listaCatalogo +
                ". Com base nesta vibe/humor: \"" + vibe + "\", escolha até 8 músicas desse catálogo que combinem bem. " +
                "Responda APENAS com os IDs separados por vírgula, sem nenhum texto extra, por exemplo: 3,7,12";

        String resposta = askLlm(prompt);

        List<Long> idsEscolhidos = new ArrayList<>();
        for (String parte : resposta.split(",")) {
            try {
                idsEscolhidos.add(Long.parseLong(parte.trim()));
            } catch (NumberFormatException ignored) {
                // ignora pedaços que não são números
            }
        }

        List<Song> musicasEscolhidas = catalogo.stream()
                .filter(s -> idsEscolhidos.contains(s.getId()))
                .collect(Collectors.toList());

        if (musicasEscolhidas.isEmpty()) {
            throw new RuntimeException("A IA não conseguiu escolher músicas do catálogo para essa vibe.");
        }

        Playlist playlist = new Playlist();
        playlist.setUser(user);
        playlist.setName((nomeDesejado != null && !nomeDesejado.isBlank()) ? nomeDesejado : "Playlist: " + vibe);
        playlist.setSongs(musicasEscolhidas);
        playlist.setDescription(buildDescription(playlist.getName(), musicasEscolhidas));

        return playlistRepository.save(playlist);
    }

    // ===== 4. Resumo do perfil musical do usuário =====

    public String summarizeUserProfile(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));

        String favoritos = user.getFavoriteSongs().stream()
                .map(this::describe)
                .collect(Collectors.joining(", "));

        String playlists = user.getPlaylists().stream()
                .flatMap(p -> p.getSongs().stream())
                .map(this::describe)
                .distinct()
                .collect(Collectors.joining(", "));

        String contexto = (favoritos + ", " + playlists).replaceAll("^, |, $", "");

        if (contexto.isBlank()) {
            return "Esse usuário ainda não tem músicas favoritas nem playlists — não dá pra traçar um perfil musical ainda.";
        }

        String prompt = "Com base nestas músicas favoritas e de playlists de um usuário: " + contexto +
                ". Escreva um resumo curto (2 a 3 frases), descontraído e em português, sobre o perfil musical dele.";

        return askLlm(prompt);
    }

    // ===== 5. Detectar gênero de uma música quando não preenchido =====

    public Song detectGenre(Long songId) {
        Song song = songRepository.findById(songId)
                .orElseThrow(() -> new RuntimeException("Música não encontrada"));

        if (song.getGenre() != null && !song.getGenre().isBlank()) {
            return song;
        }

        String artista = song.getArtist() != null ? song.getArtist().getName() : "desconhecido";

        String prompt = "Qual é o gênero musical predominante da música '" + song.getName() +
                "' do artista '" + artista + "'? Responda ESTRITAMENTE com o nome do gênero, " +
                "uma palavra ou expressão curta (ex: Rock, Britpop, MPB, Funk). " +
                "Não adicione nenhum comentário, explicação, correção ou observação — " +
                "mesmo que o artista informado pareça incorreto, responda apenas o gênero mais provável para essa música.";

        String genero = askLlm(prompt);
        song.setGenre(genero.trim());
        return songRepository.save(song);
    }

    // ===== auxiliares =====

    private String describe(Song s) {
        return s.getName() + (s.getArtist() != null ? " (" + s.getArtist().getName() + ")" : "");
    }

    private String buildDescription(String playlistName, List<Song> songs) {
        String musicas = songs.stream()
                .map(Song::getName)
                .collect(Collectors.joining(", "));

        String prompt = "Você é um curador de música. Gere uma descrição curta (1 a 2 frases), " +
                "criativa e envolvente, para uma playlist chamada '" + playlistName +
                "' que contém estas músicas: " + musicas +
                ". Responda em português, só com a descrição, sem aspas e sem introdução.";

        return askLlm(prompt);
    }

    private String askLlm(String prompt) {

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("x-api-key", apiKey);
        headers.set("anthropic-version", "2023-06-01");

        Map<String, Object> message = new HashMap<>();
        message.put("role", "user");
        message.put("content", prompt);

        Map<String, Object> body = new HashMap<>();
        body.put("model", model);
        body.put("max_tokens", 300);
        body.put("messages", List.of(message));

        HttpEntity<Map<String, Object>> request = new HttpEntity<>(body, headers);

        try {
            String response = restTemplate.postForObject(apiUrl, request, String.class);
            JsonNode root = objectMapper.readTree(response);
            return root.path("content").get(0).path("text").asText();
        } catch (Exception e) {
            return "Não foi possível gerar a resposta da IA agora: " + e.getMessage();
        }
    }
}