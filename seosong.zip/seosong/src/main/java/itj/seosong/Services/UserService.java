package itj.seosong.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import itj.seosong.Entities.Song;
import itj.seosong.Entities.User;
import itj.seosong.Repositories.SongRepository;
import itj.seosong.Repositories.UserRepository;

@Service
public class UserService {

    private final UserRepository repository;
    private final SongRepository songRepository;

    public UserService(UserRepository repository, SongRepository songRepository) {
        this.repository = repository;
        this.songRepository = songRepository;
    }

    public User create(User newUser) {
        return repository.save(newUser);
    }

    public List<User> findAll() {
        return repository.findAll();
    }

    public Optional<User> findById(Long id) {
        return repository.findById(id);
    }

    public Optional<User> update(Long id, User data) {
        return repository.findById(id).map(existing -> {
            existing.setName(data.getName());
            existing.setEmail(data.getEmail());
            existing.setPassword(data.getPassword());
            existing.setBirthDate(data.getBirthDate());
            existing.setZipCode(data.getZipCode());
            existing.setPhoto(data.getPhoto());
            return repository.save(existing);
        });
    }

    public boolean deleteById(Long id) {
        if (!repository.existsById(id)) {
            return false;
        }
        repository.deleteById(id);
        return true;
    }

    public Optional<User> addFavorite(Long userId, Long songId) {
        Optional<User> userOpt = repository.findById(userId);
        Optional<Song> songOpt = songRepository.findById(songId);

        if (userOpt.isEmpty() || songOpt.isEmpty()) {
            return Optional.empty();
        }

        User user = userOpt.get();
        Song song = songOpt.get();

        boolean jaTem = user.getFavoriteSongs().stream()
                .anyMatch(s -> s.getId().equals(song.getId()));

        if (!jaTem) {
            user.getFavoriteSongs().add(song);
            repository.save(user);
        }

        return Optional.of(user);
    }

    public Optional<User> removeFavorite(Long userId, Long songId) {
        return repository.findById(userId).map(user -> {
            user.getFavoriteSongs().removeIf(s -> s.getId().equals(songId));
            return repository.save(user);
        });
    }
}